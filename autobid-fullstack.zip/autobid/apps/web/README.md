# AutoBid — Web (Next.js)

Capture-desk UI for the AutoBid backend. Next.js 14 (App Router) + TypeScript +
Tailwind. Design: warm "command desk" — Fraunces display, Archivo body, IBM Plex
Mono for codes/scores; ink + brass on parchment, signal-colored fit scores.

## Setup

```bash
cd apps/web
npm install
cp .env.local.example .env.local      # set NEXT_PUBLIC_API_URL + NEXT_PUBLIC_COMPANY_ID
npm run dev                            # http://localhost:3000
```

`NEXT_PUBLIC_API_URL` points at the FastAPI backend (default `http://localhost:8000`).
`NEXT_PUBLIC_COMPANY_ID` is the UUID of your row in `companies` (until Supabase auth
resolves it from the JWT). Make sure the backend's `CORS_ORIGINS` includes
`http://localhost:3000`.

## Screens

| Route | What it does |
|---|---|
| `/` | Dashboard — tracked count, recommended, deadlines this week, top-fit list. |
| `/feed` | Ranked opportunity feed with score dials, recommended flag, score filters. |
| `/opportunity/[id]` | Detail — AI summary, score breakdown bars, particulars, attachments, **Start bid workspace**. |
| `/workspace/[id]` | Split view: compliance matrix (extract + satisfy/waive, attestation flags) ↔ proposal editor (draft, edit, approve/lock). **Export is blocked until the compliance gate passes.** |
| `/vault` | Company profile + document vault (approved-language reuse). |
| `/settings` | API keys reference + the security note. |

## Notes

- All data calls go through `lib/api.ts` (typed). Types mirror the backend in `lib/types.ts`.
- The export button calls the backend's gated `/export` route — a `409` there means
  the human-review gate isn't satisfied yet (open items or unsigned attestations).
- To swap the hand-rolled primitives for shadcn/ui later, run `npx shadcn@latest init`
  and replace `components/ui/primitives.tsx`.
